package com.example.bankers;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText processesEditText, resourcesEditText;
    private LinearLayout maxMatrixLayout, allocatedMatrixLayout, availableMatrixLayout, matrixLayout;
    private Button submitBtn, checkBtn;
    private TextView resultTextView;
    private int numOfProcesses, numOfResources;
    private List<EditText> maxEditTexts, allocatedEditTexts, availableEditTexts;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        processesEditText = findViewById(R.id.processesEditText);
        resourcesEditText = findViewById(R.id.resourcesEditText);
        maxMatrixLayout = findViewById(R.id.maxMatrixLayout);
        allocatedMatrixLayout = findViewById(R.id.allocatedMatrixLayout);
        availableMatrixLayout = findViewById(R.id.availableMatrixLayout);
        matrixLayout = findViewById(R.id.matrixLayout);
        submitBtn = findViewById(R.id.submitBtn);
        checkBtn = findViewById(R.id.checkBtn);
        resultTextView = findViewById(R.id.resultTextView);
        maxEditTexts = new ArrayList<>();
        allocatedEditTexts = new ArrayList<>();
        availableEditTexts = new ArrayList<>();

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numOfProcesses = Integer.parseInt(processesEditText.getText().toString());
                numOfResources = Integer.parseInt(resourcesEditText.getText().toString());

                for (int i = 0; i < numOfProcesses; i++) {
                    LinearLayout rowLayout = new LinearLayout(MainActivity.this);
                    rowLayout.setOrientation(LinearLayout.HORIZONTAL);
                    for (int j = 0; j < numOfResources; j++) {
                        EditText editText = new EditText(MainActivity.this);
                        editText.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
                        editText.setEms(4);
                        editText.setTextSize(18);
                        rowLayout.addView(editText);
                        maxEditTexts.add(editText);
                    }
                    maxMatrixLayout.addView(rowLayout);
                }

                for (int i = 0; i < numOfProcesses; i++) {
                    LinearLayout rowLayout = new LinearLayout(MainActivity.this);
                    rowLayout.setOrientation(LinearLayout.HORIZONTAL);
                    for (int j = 0; j < numOfResources; j++) {
                        EditText editText = new EditText(MainActivity.this);
                        editText.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
                        editText.setEms(4);
                        editText.setTextSize(18);
                        rowLayout.addView(editText);
                        allocatedEditTexts.add(editText);
                    }
                    allocatedMatrixLayout.addView(rowLayout);
                }

                LinearLayout availableRowLayout = new LinearLayout(MainActivity.this);
                availableRowLayout.setOrientation(LinearLayout.HORIZONTAL);
                for (int j = 0; j < numOfResources; j++) {
                    EditText editText = new EditText(MainActivity.this);
                    editText.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
                    editText.setEms(4);
                    editText.setTextSize(18);
                    availableRowLayout.addView(editText);
                    availableEditTexts.add(editText);
                }
                availableMatrixLayout.addView(availableRowLayout);

                matrixLayout.setVisibility(View.VISIBLE);
                checkBtn.setVisibility(View.VISIBLE);
            }
        });

        checkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int[][] max = new int[numOfProcesses][numOfResources];
                int[][] allocated = new int[numOfProcesses][numOfResources];
                int[] available = new int[numOfResources];

                int index = 0;
                for (int i = 0; i < numOfProcesses; i++) {
                    for (int j = 0; j < numOfResources; j++) {
                        max[i][j] = Integer.parseInt(maxEditTexts.get(index).getText().toString());
                        allocated[i][j] = Integer.parseInt(allocatedEditTexts.get(index).getText().toString());
                        index++;
                    }
                }

                for (int j = 0; j < numOfResources; j++) {
                    available[j] = Integer.parseInt(availableEditTexts.get(j).getText().toString());
                }

                BankersAlgorithm bankers = new BankersAlgorithm(max, allocated, available);
                boolean isSafe = bankers.isSafe();

                if (isSafe) {
                    resultTextView.setText("The system is in a safe state.");
                } else {
                    resultTextView.setText("The system is NOT in a safe state.");
                }
                resultTextView.setVisibility(View.VISIBLE);
            }
        });
    }
}