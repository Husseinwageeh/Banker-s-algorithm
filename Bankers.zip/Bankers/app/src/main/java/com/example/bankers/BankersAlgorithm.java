package com.example.bankers;

import java.util.Arrays;

public class BankersAlgorithm {
    private int numOfProcesses, numOfResources;
    private int[][] max,allocated;
    private int[] available;

    public BankersAlgorithm(int[][] max, int[][] allocated, int[] available) {
        this.numOfProcesses = max.length;
        this.numOfResources = available.length;
        this.max = max;
        this.allocated = allocated;
        this.available = available;
    }

    public boolean isSafe() {
        int[] work = Arrays.copyOf(available, available.length);
        boolean[] finish = new boolean[numOfProcesses];
        int i = 0;
        while (i < numOfProcesses) {
            if (!finish[i] && lessThanOrEqual(max[i], work)) {
                break;
            }
            i++;
        }

        if (i == numOfProcesses) {
            return true;
        }

        for (int j = 0; j < numOfResources; j++) {
            work[j] += allocated[i][j];
        }
        finish[i] = true;
        while (true) {
            i = 0;
            while (i < numOfProcesses) {
                if (!finish[i] && lessThanOrEqual(max[i], work)) {
                    break;
                }
                i++;
            }


            boolean deadlockDetected = true;
            for (int j = 0; j < numOfResources; j++) {
                if (max[i][j] - allocated[i][j] > work[j]) {
                    deadlockDetected = false;
                    break;
                }
            }

            if (deadlockDetected) {
                return false;
            }
            for (int j = 0; j < numOfResources; j++) {
                work[j] += allocated[i][j];
            }
            finish[i] = true;
        }
    }

    private boolean lessThanOrEqual(int[] a, int[] b) {
        for (int i = 0; i < a.length; i++) {
            if (a[i] > b[i]) {
                return false;
            }
        }
        return true;
    }
}
